# Turn your SOPs into AI skills

Free from Korede Kolawole, Content Systems.ai.

## What's inside
- /sop-to-skill
- /skill-test

## How to install
- Claude Code: copy each folder into ~/.claude/skills/ (or .claude/skills/ in a project). Run it with /<name>.
- Claude app: Settings, Capabilities, Skills, upload the folder as a zip.
- ChatGPT or any other AI chat: create a project and paste the SKILL.md text into its instructions.

## Before you use them on real work
Run each skill on last week's work first. Anything that sends, pays, posts or deletes waits for your yes.
